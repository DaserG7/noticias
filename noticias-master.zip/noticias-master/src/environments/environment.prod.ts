export const environment = {
  production: true,
  apiKey: '3b434184f5114416973ffb57fe1224c7',
  apiUrl: 'https://newsapi.org/v2'
};
